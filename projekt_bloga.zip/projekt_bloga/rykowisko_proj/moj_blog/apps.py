from django.apps import AppConfig


class MojBlogConfig(AppConfig):
    name = 'moj_blog'
